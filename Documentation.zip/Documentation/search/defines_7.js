var searchData=
[
  ['white_128',['WHITE',['../_square__functions_8cpp.html#a87b537f5fa5c109d3c05c13d6b18f382',1,'Square_functions.cpp']]]
];
