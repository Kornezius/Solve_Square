var searchData=
[
  ['ok_5fpicture_38',['ok_picture',['../_square__functions_8cpp.html#a9e2881a545d06aa7a7f53c1a4e9e2d9b',1,'ok_picture():&#160;Square_main.cpp'],['../_square__main_8cpp.html#a9e2881a545d06aa7a7f53c1a4e9e2d9b',1,'ok_picture():&#160;Square_main.cpp']]],
  ['output_39',['output',['../_square__functions_8cpp.html#a2f4e974cbcf0561c175fd8d515d2e909',1,'output(int r, double x1, double x2):&#160;Square_main.cpp'],['../_square__main_8cpp.html#a93f38777fdcc6732e24a85454bc56a79',1,'output(int answ, double x1, double x2):&#160;Square_main.cpp']]]
];
