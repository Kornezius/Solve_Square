var searchData=
[
  ['green_121',['GREEN',['../_square__functions_8cpp.html#acfbc006ea433ad708fdee3e82996e721',1,'Square_functions.cpp']]]
];
