var searchData=
[
  ['a_93',['a',['../structtest_case.html#acd403bddeb753708f3a9880cca77db81',1,'testCase']]],
  ['all_5ftests_5fprogram_94',['all_tests_program',['../_square__functions_8cpp.html#a361c32656a7283c4e32159d141020417',1,'Square_functions.cpp']]],
  ['answ_5fref_95',['answ_ref',['../structtest_case.html#a554cda5f924b29bb0001ef655f927a2e',1,'testCase']]]
];
