var searchData=
[
  ['blue_117',['BLUE',['../_square__functions_8cpp.html#a79d10e672abb49ad63eeaa8aaef57c38',1,'Square_functions.cpp']]]
];
