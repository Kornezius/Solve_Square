var searchData=
[
  ['b_4',['b',['../structtest_case.html#a4eb90f659959500533fd72efe8c2dcda',1,'testCase']]],
  ['blue_5',['BLUE',['../_square__functions_8cpp.html#a79d10e672abb49ad63eeaa8aaef57c38',1,'Square_functions.cpp']]]
];
