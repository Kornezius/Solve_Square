var searchData=
[
  ['magenta_122',['MAGENTA',['../_square__functions_8cpp.html#a6f699060902f800f12aaae150f3a708e',1,'Square_functions.cpp']]],
  ['my_5fassert_123',['my_assert',['../_square__functions_8cpp.html#aa5c0449dcc7d884cda0aa0f26d21b0d7',1,'Square_functions.cpp']]]
];
