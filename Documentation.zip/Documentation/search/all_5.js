var searchData=
[
  ['hello_5fpicture_25',['hello_picture',['../_square__functions_8cpp.html#a12494984b451ea7dba274f20167f370f',1,'hello_picture():&#160;Square_main.cpp'],['../_square__main_8cpp.html#a12494984b451ea7dba274f20167f370f',1,'hello_picture():&#160;Square_main.cpp']]]
];
