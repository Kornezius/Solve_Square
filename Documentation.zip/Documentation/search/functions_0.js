var searchData=
[
  ['count_5fof_5fcheck_71',['count_of_check',['../_square__functions_8cpp.html#aa2647cee868376472f28a00686914a7a',1,'count_of_check(int run_test_check):&#160;Square_tests.cpp'],['../_square__tests_8cpp.html#aa2647cee868376472f28a00686914a7a',1,'count_of_check(int run_test_check):&#160;Square_tests.cpp']]]
];
