var searchData=
[
  ['red_126',['RED',['../_square__functions_8cpp.html#a8d23feea868a983c8c2b661e1e16972f',1,'Square_functions.cpp']]]
];
