var searchData=
[
  ['solve_20square_130',['Solve Square',['../index.html',1,'']]],
  ['solve_5fsquare_131',['Solve_Square',['../md__r_e_a_d_m_e.html',1,'']]]
];
